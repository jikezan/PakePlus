import{_ as p}from"./setpaypwd.vue_vue_type_script_setup_true_lang.BFssetrp.js";import"./index-Duwb82h8.js";import"./uni-app.es.D2cl9MrP.js";import"./user.DzJKUk0Z.js";export{p as default};
