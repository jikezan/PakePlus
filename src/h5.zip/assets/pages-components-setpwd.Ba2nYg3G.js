import{_ as e}from"./setpwd.vue_vue_type_script_setup_true_lang.DL7-RIpF.js";import"./index-Duwb82h8.js";import"./uni-app.es.D2cl9MrP.js";import"./user.DzJKUk0Z.js";export{e as default};
