import{_ as e}from"./bankinfo.vue_vue_type_script_setup_true_lang.CSPYOoDY.js";import"./index-Duwb82h8.js";import"./user.DzJKUk0Z.js";export{e as default};
