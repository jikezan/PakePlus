import{a6 as a,a7 as s,a8 as o,a9 as r}from"./index-Duwb82h8.js";function t(a,s){return"string"==typeof a?s:a}const n=(o=>(t,n=a())=>{!r&&s(o,t,n)})(o);export{n as o,t as r};
